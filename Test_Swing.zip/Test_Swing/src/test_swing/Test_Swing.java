
package test_swing;


import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

/**
 *
 * @author Ghailen
 */

public class Test_Swing extends JFrame {
    
        private  JButton Bouton1,Bouton2,Bouton3;
        private  JTextField Txt1,Txt2,Txt3;
        
        
        public Test_Swing(){
            
            this.setTitle("Exercie 1");
            this.setSize(500, 400);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLocationRelativeTo(null);//lancement au centre d'afficheur
    		
            Bouton1= new JButton("Nom");       Bouton1.setBackground(Color.yellow);
            Bouton2= new JButton("Telephone"); Bouton2.setBackground(Color.red);
            Bouton3= new JButton("Adresse");   Bouton3.setBackground(Color.blue);
    
            Txt1= new JTextField("Bonjour");
            Txt2= new JTextField("Génie");
            Txt3= new JTextField("Telecom");
           
    
            this.setLayout(new GridLayout(3, 2));
            
            this.getContentPane().add(Bouton1);
            this.getContentPane().add(Txt1);
            this.getContentPane().add(Bouton2);
            this.getContentPane().add(Txt2);
            this.getContentPane().add(Bouton3);
            this.getContentPane().add(Txt3);
    
            this.setVisible(true);
  }
        
     public static void main(String[] args){
     Test_Swing p =new Test_Swing();
    
  }    
}
